<?php
if (!defined('ABSPATH')) { exit; }

/**
 * One-click self-update from a public GitHub repo, so new versions install
 * straight from the wp-admin Plugins page (WordPress' own updater) — no FTP,
 * no FPM-wedge. The repo hosts a tiny manifest and the folder-rooted zip:
 *
 *   https://raw.githubusercontent.com/<REPO>/<BRANCH>/update.json
 *     { "version":"2.3.0",
 *       "download_url":"https://raw.githubusercontent.com/<REPO>/<BRANCH>/matova-hbook-api.zip",
 *       "requires":"5.8", "tested":"6.7", "changelog":"..." }
 *
 * The zip must contain a top-level `matova-hbook-api/` folder (as our build
 * does), so WordPress replaces the plugin in place.
 */
class MHA_Updater {

    // Set once the repo exists. Public repo so no token is needed in the plugin.
    const REPO   = 'jakubmatuska-ops/matova-hbook-api';
    const BRANCH = 'main';
    const SLUG   = 'matova-hbook-api';                      // plugin folder
    const FILE   = 'matova-hbook-api/matova-hbook-api.php'; // plugin basename

    public static function init() {
        add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'inject']);
        add_filter('plugins_api', [__CLASS__, 'info'], 20, 3);
        add_filter('upgrader_source_selection', [__CLASS__, 'rename_source'], 10, 4);
        add_action('upgrader_process_complete', [__CLASS__, 'flush']);
    }

    private static function manifest_url() {
        return 'https://raw.githubusercontent.com/' . self::REPO . '/' . self::BRANCH . '/update.json';
    }

    public static function flush() { delete_transient('mha_update_manifest'); }

    /** Fetch + cache the remote manifest (6h on success, 3h on failure). */
    private static function manifest() {
        $cached = get_transient('mha_update_manifest');
        if (is_array($cached)) { return $cached; }
        if ($cached === 'none') { return null; }

        $resp = wp_remote_get(self::manifest_url(), [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json', 'User-Agent' => 'matova-hbook-api'],
        ]);
        if (is_wp_error($resp) || (int) wp_remote_retrieve_response_code($resp) !== 200) {
            set_transient('mha_update_manifest', 'none', 3 * HOUR_IN_SECONDS);
            return null;
        }
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!is_array($data) || empty($data['version']) || empty($data['download_url'])) {
            set_transient('mha_update_manifest', 'none', 3 * HOUR_IN_SECONDS);
            return null;
        }
        set_transient('mha_update_manifest', $data, 6 * HOUR_IN_SECONDS);
        return $data;
    }

    private static function current() { return defined('MHA_VERSION') ? MHA_VERSION : '0'; }

    public static function inject($transient) {
        if (!is_object($transient)) { return $transient; }
        $m = self::manifest();
        if (!$m) { return $transient; }

        $cur = self::current();
        if (version_compare((string) $m['version'], $cur, '>')) {
            if (!isset($transient->response)) { $transient->response = []; }
            $transient->response[self::FILE] = (object) [
                'slug'        => self::SLUG,
                'plugin'      => self::FILE,
                'new_version' => (string) $m['version'],
                'package'     => (string) $m['download_url'],
                'url'         => 'https://github.com/' . self::REPO,
                'tested'      => isset($m['tested']) ? (string) $m['tested'] : '',
                'requires'    => isset($m['requires']) ? (string) $m['requires'] : '',
            ];
            if (isset($transient->no_update[self::FILE])) { unset($transient->no_update[self::FILE]); }
        } else {
            if (!isset($transient->no_update)) { $transient->no_update = []; }
            $transient->no_update[self::FILE] = (object) [
                'slug' => self::SLUG, 'plugin' => self::FILE, 'new_version' => $cur,
                'package' => '', 'url' => 'https://github.com/' . self::REPO,
            ];
        }
        return $transient;
    }

    public static function info($res, $action, $args) {
        if ($action !== 'plugin_information') { return $res; }
        if (empty($args->slug) || $args->slug !== self::SLUG) { return $res; }
        $m = self::manifest();
        if (!$m) { return $res; }
        return (object) [
            'name'          => 'Matova HBook API',
            'slug'          => self::SLUG,
            'version'       => (string) $m['version'],
            'author'        => 'Matova Group',
            'homepage'      => 'https://github.com/' . self::REPO,
            'download_link' => (string) $m['download_url'],
            'requires'      => isset($m['requires']) ? (string) $m['requires'] : '',
            'tested'        => isset($m['tested']) ? (string) $m['tested'] : '',
            'sections'      => [
                'description' => 'Unified HBook REST API for Matova Group resorts (matova/v2).',
                'changelog'   => isset($m['changelog']) ? (string) $m['changelog'] : '',
            ],
        ];
    }

    /**
     * Our zip is already folder-rooted (matova-hbook-api/…), so this is just a
     * safety net: if a download ever extracts to a suffixed folder, rename it to
     * the plugin slug so WordPress overwrites in place instead of making a copy.
     */
    public static function rename_source($source, $remote_source, $upgrader, $extra = []) {
        if (empty($extra['plugin']) || $extra['plugin'] !== self::FILE) { return $source; }
        if (!function_exists('trailingslashit')) { return $source; }
        $desired = trailingslashit($remote_source) . self::SLUG . '/';
        if (trailingslashit($source) === $desired) { return $source; }
        if (is_dir($source) && @rename($source, $desired)) { return $desired; }
        return $source;
    }
}
