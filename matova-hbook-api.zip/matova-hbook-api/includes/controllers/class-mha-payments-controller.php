<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Payments controller.
 *   POST /reservations/{id}/payments   (ops-write)
 *
 * Appends to HBook's payments_logs via native methods only — NEVER the flat
 * `paid` column (CONTRACTS §4).
 */
class MHA_Payments_Controller extends MHA_Controller {

    public function register() {
        register_rest_route($this->ns(), '/reservations/(?P<id>\d+)/payments', [
            'methods'             => 'POST',
            'callback'            => [$this, 'add_payment'],
            'permission_callback' => MHA_Auth::require_scope('ops-write'),
        ]);
    }

    public function add_payment(WP_REST_Request $req) {
        $id = (int) $req->get_param('id');
        return $this->mutate(
            $req, 'POST /reservations/{id}/payments', 'reservation', $id,
            function () use ($id) { return MHA_HBook::reservation($id); },
            function () use ($req, $id) {
                $is_parent = (bool) $req->get_param('is_parent');

                // Target must exist (single or parent).
                if ($is_parent) {
                    if (!MHA_HBook::parent_reservation($id)) {
                        return new WP_Error('not_found', 'Parent reservation not found.', ['status' => 404]);
                    }
                } else {
                    if (!MHA_HBook::reservation($id)) {
                        return new WP_Error('not_found', 'Reservation not found.', ['status' => 404]);
                    }
                }

                $amount = MHA_Request::int_param($req, 'amount', false);
                // Accept float amounts via body too.
                $raw_amount = $req->get_param('amount');
                if ($raw_amount === null || $raw_amount === '') {
                    return new WP_Error('bad_request', 'Missing payment amount.', ['status' => 400]);
                }
                if (!is_numeric($raw_amount)) {
                    return new WP_Error('bad_request', 'Payment amount must be numeric.', ['status' => 400]);
                }
                $amount = (float) $raw_amount;
                if ($amount == 0.0) {
                    return new WP_Error('bad_request', 'Payment amount must be non-zero.', ['status' => 400]);
                }

                $method = MHA_Request::string_param($req, 'method', false, 64);
                if (is_wp_error($method)) { return $method; }
                $note = MHA_Request::string_param($req, 'note', false, 1000);
                if (is_wp_error($note)) { return $note; }

                $payment = [
                    'amount' => $amount,
                    'date'   => gmdate('Y-m-d H:i:s'),
                    'method' => $method ?: 'manual',
                    'note'   => $note ?: '',
                    'source' => 'matova/v2',
                ];
                return MHA_HBook::add_payment($id, $is_parent, $payment);
            }
        );
    }
}
